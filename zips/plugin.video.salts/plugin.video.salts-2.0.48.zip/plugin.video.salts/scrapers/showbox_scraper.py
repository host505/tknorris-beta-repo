"""
    SALTS XBMC Addon
    Copyright (C) 2014 tknorris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import urlparse
from salts_lib import kodi
from salts_lib import log_utils
from salts_lib import scraper_utils
from salts_lib import dom_parser
from salts_lib.constants import FORCE_NO_MATCH
from salts_lib.constants import VIDEO_TYPES
from salts_lib.constants import QUALITIES
import scraper

BASE_URL = 'https://show-box.co'
XHR = {'X-Requested-With': 'XMLHttpRequest'}

class ShowBox_Scraper(scraper.Scraper):
    base_url = BASE_URL

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting('%s-base_url' % (self.get_name()))

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'ShowBox'

    def resolve_link(self, link):
        return link

    def format_source_label(self, item):
        label = '[%s] %s' % (item['quality'], item['host'])
        return label

    def get_sources(self, video):
        source_url = self.get_url(video)
        hosters = []
        if source_url and source_url != FORCE_NO_MATCH:
            url = urlparse.urljoin(self.base_url, source_url)
            html = self._http_get(url, cache_limit=.5)
            fragment = dom_parser.parse_dom(html, 'div', {'class': 'video-embed'})
            if fragment:
                for iframe_url in dom_parser.parse_dom(fragment[0], 'iframe', ret='data-lazy-src') + dom_parser.parse_dom(fragment[0], 'iframe', ret='src'):
                    if not iframe_url.startswith('http'): continue
                    host = urlparse.urlparse(iframe_url).hostname
                    hoster = {'multi-part': False, 'host': host, 'class': self, 'quality': QUALITIES.HD720, 'views': None, 'rating': None, 'url': iframe_url, 'direct': False}
                    hosters.append(hoster)

        return hosters

    def _get_episode_url(self, show_url, video):
        page_url = show_url = urlparse.urljoin(self.base_url, show_url)
        headers = None
        while show_url:
            html = self._http_get(show_url, headers=headers, cache_limit=8)
            fragment = dom_parser.parse_dom(html, 'ul', {'class': '[^"]*listing-videos[^"]*'})
            if fragment:
                pattern = 'href="([^"]+)[^>]*title="[^"]*S0*%sE0*%s"' % (video.season, video.episode)
                match = re.search(pattern, fragment[0], re.I)
                if match:
                    return scraper_utils.pathify_url(match.group(1))
                
                match = re.search('"nextLink"\s*:\s*"([^"]+)', html)
                if match:
                    show_url = match.group(1)
                    show_url = show_url.replace('\/', '/')
                    headers = XHR
                    headers['Referer'] = page_url
                else:
                    show_url = ''

    def search(self, video_type, title, year, season=''):
        results = []
        url = urlparse.urljoin(self.base_url, '/categories')
        html = self._http_get(url, cache_limit=48)
        fragment = dom_parser.parse_dom(html, 'ul', {'class': 'listing-cat'})
        if fragment:
            links = dom_parser.parse_dom(fragment[0], 'a', ret='href')
            titles = dom_parser.parse_dom(fragment[0], 'a', ret='title')
            norm_title = scraper_utils.normalize_title(title)
            for link, match_title in zip(links, titles):
                if norm_title in scraper_utils.normalize_title(match_title):
                    result = {'url': scraper_utils.pathify_url(link), 'title': scraper_utils.cleanse_title(match_title), 'year': ''}
                    results.append(result)

        return results
